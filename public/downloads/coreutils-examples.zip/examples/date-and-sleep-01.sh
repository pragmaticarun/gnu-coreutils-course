#!/usr/bin/env bash
# Example from the GNU Coreutils Workbench (date-and-sleep).
# Re-run inside a scratch directory. Captured against GNU coreutils 9.4.
set -eo pipefail

cd "$(mktemp -d)"
/usr/bin/date -u -d @1700000000 '+%Y-%m-%dT%H:%M:%SZ'
