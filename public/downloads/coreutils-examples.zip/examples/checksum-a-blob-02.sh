#!/usr/bin/env bash
# Example from the GNU Coreutils Workbench (checksum-a-blob).
# Re-run inside a scratch directory. Captured against GNU coreutils 9.4.
set -eo pipefail

cd "$(mktemp -d)"
/usr/bin/printf 'abc' > blob
/usr/bin/sha256sum blob > MANIFEST
/usr/bin/sha256sum -c MANIFEST
