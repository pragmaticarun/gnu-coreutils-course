#!/usr/bin/env bash
# Example from the GNU Coreutils Workbench (gnu-tar).
# Re-run inside a scratch directory. Captured against GNU coreutils 9.4.
set -eo pipefail

if [ "$(id -u)" -eq 0 ]; then
  printf 'Refusing to run as root.\n' >&2
  exit 1
fi
cd "$(mktemp -d)"
/usr/bin/printf 'keep\n' > keep.txt
/usr/bin/printf 'drop\n' > drop.txt
/usr/bin/tar --exclude=drop.txt -cf bundle.tar keep.txt drop.txt
/usr/bin/tar -tf bundle.tar
/usr/bin/mkdir out
/usr/bin/tar -xf bundle.tar -C out
/usr/bin/cat out/keep.txt
